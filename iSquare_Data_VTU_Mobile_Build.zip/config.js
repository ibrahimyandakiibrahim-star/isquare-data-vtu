// Optional configuration for cloud/mobile packaging.
// Replace the URL with your deployed backend API.
// Example: window.ISQUARE_API = 'https://api.example.com/api';
window.ISQUARE_API = 'https://your-domain.com/api';
