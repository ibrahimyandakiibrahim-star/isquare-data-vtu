# iSquare Data VTU — Mobile Build Package

This package is optimized for uploading from a phone.

## 1. Backend URL
Edit `config.js` and replace:
https://your-domain.com/api
with your public HTTPS backend API URL.

## 2. Test the web app
Open `www/index.html` after setting the URL.

## 3. Cloud/mobile build
The `www` folder is the web app source. It can be imported into a supported cloud Android/web-to-app builder or packaged with Capacitor.

## Important
The backend must be publicly reachable over HTTPS. The previous Node backend using `localhost:3000` cannot be reached by a phone over the internet.

Demo wallet funding is not real payment. Data/Airtime services require a legitimate VTU provider and payment gateway.
